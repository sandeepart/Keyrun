package kawa.lang;

public class GenericError extends RuntimeException {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public GenericError(String message) {
        super(message);
    }
}
